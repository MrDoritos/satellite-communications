#!/bin/bash
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root"
   exit 1
fi
#Copy configs
cp dnsmasq.conf /etc/dnsmasq.conf

service dnsmasq start

#Up interfaces with their IPs
ifconfig eth0 10.0.0.1 netmask 255.0.0.0 up
ifconfig wlan0 1.1.1.1 netmask 255.255.255.252 up

#Create NAT between station and site
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
sysctl net.ipv4.ip_forward=1
iptables -P FORWARD ACCEPT
iptables -F FORWARD

rfkill unblock wlan

#Create satellite link
hostapd -B hostapd.conf
